package socialnetwork.utils.events;

public enum ChangeEventType {
    ADD,
    DELETE,
    UPDATE;
}
