package socialnetwork.repository.exception;

public class Exception extends RuntimeException {

    public Exception(){};
    public Exception(String message){super(message);};
}
