package socialnetwork.utils.events;

public interface Event {
}
