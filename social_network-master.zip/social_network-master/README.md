# social_network
Social_Network is an application made in Java and JavaFX for GUI, using concepts like OOP and Desing Patterns (Factory and Observer)

The app allows the following:
- log in
- send/receive friendship requests
- accept/reject requests
- delete requests
- show all friendships
- delete friendship
- send/reply message
- log out
